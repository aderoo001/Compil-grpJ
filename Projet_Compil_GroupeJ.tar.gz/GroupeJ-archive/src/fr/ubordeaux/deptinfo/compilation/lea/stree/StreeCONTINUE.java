package fr.ubordeaux.deptinfo.compilation.lea.stree;

import fr.ubordeaux.deptinfo.compilation.lea.type.TypeException;

public class StreeCONTINUE extends Stree {

	public StreeCONTINUE() throws TypeException, StreeException {
		super();
	}

}
