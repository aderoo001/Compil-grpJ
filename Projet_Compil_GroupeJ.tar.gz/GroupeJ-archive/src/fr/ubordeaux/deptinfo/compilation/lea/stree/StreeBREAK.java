package fr.ubordeaux.deptinfo.compilation.lea.stree;

import fr.ubordeaux.deptinfo.compilation.lea.type.TypeException;

public class StreeBREAK extends Stree {

	public StreeBREAK() throws TypeException, StreeException {
		super();
	}

}
