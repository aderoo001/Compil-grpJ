package fr.ubordeaux.deptinfo.compilation.lea.stree;

import fr.ubordeaux.deptinfo.compilation.lea.type.TypeException;

public class StreeTABLE extends Stree {

	public StreeTABLE(Stree left) throws TypeException, StreeException {
		super(left);
	}

}
