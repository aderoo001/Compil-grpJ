package fr.ubordeaux.deptinfo.compilation.lea.stree;

public class StreeException extends Exception {

	public StreeException(String message) {
		super(message);
	}

}
