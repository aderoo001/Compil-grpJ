package fr.ubordeaux.deptinfo.compilation.lea.stree;

import fr.ubordeaux.deptinfo.compilation.lea.type.TypeException;

public class StreeNULL extends Stree {

	public StreeNULL() throws TypeException, StreeException {
		super();
	}

}
