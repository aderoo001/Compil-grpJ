# Compil-grpJ

## Structure implémenté : for

Nous avons implémenté la boucle for, cependant l'enhanced for n'a pas
été implémenté. Pour les labels, nous avons choisi de créer un list de label
transmit par le parser dans le constructeur de la class StreeFORCONT.
De plus nous avons implémté les affectations, comparaison, logique 
ainsi que les types float, char et string.